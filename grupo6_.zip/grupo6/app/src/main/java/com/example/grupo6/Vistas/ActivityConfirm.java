package com.example.grupo6.Vistas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.grupo6.R;

public class ActivityConfirm extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm);
    }
}